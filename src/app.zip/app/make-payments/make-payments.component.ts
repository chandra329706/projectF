import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-make-payments',
  templateUrl: './make-payments.component.html',
  styleUrls: ['./make-payments.component.css']
})
export class MakePaymentsComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
