import { Component, OnInit, ElementRef, ViewChild } from '@angular/core';
import {RentReceiptService} from './rent-receipts.service';
import {NgForm} from '@angular/forms';
declare let jsPDF; 
@Component({
  selector: 'app-rent-receipts',
  templateUrl: './rent-receipts.component.html',
  styleUrls: ['./rent-receipts.component.css'],
  providers : [RentReceiptService]
})
export class RentReceiptsComponent implements OnInit {

  constructor(private _rentReceptService : RentReceiptService) { }

  UserStatus : any;
  Disabled : boolean = false;

  ngOnInit() {
    //this.UserStatus = localStorage.getItem('UserStatus');
    this._rentReceptService.getUserStatus().subscribe(Udata => {
      this.UserStatus = Udata.user_status;
      if(this.UserStatus){
        this.Disabled = true;
      }     
    })
  }

  getRecipt(rentReceiptForm : NgForm){
    // this._rentReceptService.storeRecepitValues(rentReceiptForm.value);
    let doc = new jsPDF();
    
    doc.text(20, 20, 'Name of Tenant - '+rentReceiptForm.value.tenant_name);
    doc.text(20, 30, 'House / Door / Flat# Number - '+rentReceiptForm.value.house_no);
    doc.text(20, 40, 'Name of Owner - '+rentReceiptForm.value.owner_name);
    doc.text(20, 50, 'Email ID - '+rentReceiptForm.value.email_id);
    doc.text(20, 60, 'Mobile Number - '+rentReceiptForm.value.mobile_number);
    doc.text(20, 70, 'Owners Pan - '+rentReceiptForm.value.owner_pan);
    doc.text(20, 80, 'Locality - '+rentReceiptForm.value.locality);
    doc.text(20, 90, 'Monthly Rent Amount - '+rentReceiptForm.value.rent_amount);
    doc.text(20, 100, 'Reciept start Date - '+rentReceiptForm.value.start_date);
    doc.text(20, 110, 'Reciept end Date - '+rentReceiptForm.value.end_date);
    doc.text(20, 120, 'Area - '+rentReceiptForm.value.area);
    doc.text(20, 130, 'City - '+rentReceiptForm.value.city);
    doc.text(20, 140, 'State - '+rentReceiptForm.value.state);
    doc.text(20, 150, 'Pincode - '+rentReceiptForm.value.pincode);
      // Save the PDF
    doc.save(localStorage.getItem('currentUserName')+'_rent_reciept_'+Date.now()+'.pdf');
    rentReceiptForm.reset();
    
  }

}
