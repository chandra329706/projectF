import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-payment-response',
  templateUrl: './payment-response.component.html',
  styleUrls: ['./payment-response.component.css']
})
export class PaymentResponseComponent {

  constructor() { }

  
  ngOnInit() {
  }

}
