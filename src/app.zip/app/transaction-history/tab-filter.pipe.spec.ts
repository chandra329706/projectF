/* tslint:disable:no-unused-variable */

import { TestBed, async } from '@angular/core/testing';
import { TabFilterPipe } from './tab-filter.pipe';

describe('TabFilterPipe', () => {
  it('create an instance', () => {
    const pipe = new TabFilterPipe();
    expect(pipe).toBeTruthy();
  });
});
