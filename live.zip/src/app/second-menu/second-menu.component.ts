import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-second-menu',
  templateUrl: './second-menu.component.html',
  styleUrls: ['./second-menu.component.css']
})
export class SecondMenuComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
