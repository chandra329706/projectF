import {Injectable} from '@angular/core';
import {Http, Headers, RequestOptions} from '@angular/http';
import 'rxjs/add/operator/map';


@Injectable()

export class NavBarService {

    constructor(private _http : Http){}

    baseUrl :string = 'http://api.flexypay.in/v1/';
    inputParams :any = {};
    headers = new Headers({'Content-Type':'Application/json','Accept':'application/json'});
    requestOptions = new RequestOptions({'headers':this.headers});


}