import { Component, OnInit, ElementRef, ViewChild } from '@angular/core';
import * as jsPDF from 'jspdf'

@Component({
  selector: 'app-generate-invoice',
  templateUrl: './generate-invoice.component.html',
  styleUrls: ['./generate-invoice.component.css']
})
export class GenerateInvoiceComponent implements OnInit {

  mainData: any = {};
  from: any = {};
  to: any = {};
  invoice: any = {};
  UserStatus : any;
  productsList: any = [{}];

  constructor() { }
  
  @ViewChild('pdfMaker') el: ElementRef;

  // AppendHtml : any = '<tr><td>1</td><td><input type="text" class="form-control" placeholder="abcd"></td><td><input type="text" class="form-control" placeholder="3"></td><td> <input type="text" class="form-control" placeholder="5000"></td><td> <input type="text" class="form-control" placeholder="---"></td><td> <input type="text" class="form-control" placeholder="Service Tax"></td><td> <input type="text" class="form-control" placeholder="14%"></td><td> <input type="text" class="form-control" placeholder="5245"></td></tr>'
  AppendHtml : string = '<input type="text" class="form-control" placeholder="abcd">';
  // AppendHtml = "Sample text";

  ngOnInit() {
    this.mainData.payer="sender";
    this.UserStatus = localStorage.getItem('UserStatus');
  }

  addNewRow(){
    this.productsList.push({});
  }

  downloadData(){
    console.log('from data');
    console.log(this.from);
    console.log('to data');
    console.log(this.to);
    console.log('main data');
    console.log(this.mainData);
    console.log(this.productsList);

    //For PDF Download
    var doc = new jsPDF();
    let options = { };
    doc.addHTML(this.el.nativeElement, 0, 0, options, () => {
      doc.save("Flexypay Invoice.pdf");
   });
  }


}